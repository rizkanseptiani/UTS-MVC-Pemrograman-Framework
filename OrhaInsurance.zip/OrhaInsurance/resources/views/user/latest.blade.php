<div class="page-section bg-light">
    <div class="container">
      <h1 class="text-center wow fadeInUp">Berita Terbaru</h1>
      <div class="row mt-5">
        <div class="col-lg-4 py-2 wow zoomIn">
          <div class="card-blog">
            <div class="header">
              <div class="post-category">
                <a href="#">Pandemic</a>
              </div>
              <a href='https://www.cnnindonesia.com/gaya-hidup/20220604073314-255-804702/bertambah-total-pasien-cacar-monyet-di-prancis-jadi-51-kasus' class="post-thumb">
                <img src="../assets/img/blog/berita_1.jpeg" alt="">
              </a>
            </div>
            <div class="body">
              <h5 class="post-title"><a href='https://www.cnnindonesia.com/gaya-hidup/20220604073314-255-804702/bertambah-total-pasien-cacar-monyet-di-prancis-jadi-51-kasus'>Bertambah, Total Pasien Cacar Monyet di Prancis Jadi 51 Kasus</a></h5>
              <div class="site-info">
                <div class="avatar mr-2">
                  <div class="avatar-img">
                    <img src="../assets/img/person/CNN.png" alt="">
                  </div>
                  <span>CNN Indonesia</span>
                </div>
                <span class="mai-time"></span> 1 day ago
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 py-2 wow zoomIn">
          <div class="card-blog">
            <div class="header">
              <div class="post-category">
                <a href="#">Covid19</a>
              </div>
              <a href='https://health.detik.com/berita-detikhealth/d-6110373/riset-as-sebut-orang-dengan-alergi-makanan-lebih-aman-dari-covid-19-kok-bisa' class="post-thumb">
                <img src="../assets/img/blog/berita_2.jpeg" alt="">
              </a>
            </div>
            <div class="body">
              <h5 class="post-title"><a href='https://health.detik.com/berita-detikhealth/d-6110373/riset-as-sebut-orang-dengan-alergi-makanan-lebih-aman-dari-covid-19-kok-bisa'>Riset AS sebut orang dengan alergi makanan lebih aman</a></h5>
              <div class="site-info">
                <div class="avatar mr-2">
                  <div class="avatar-img">
                    <img src="../assets/img/person/DETIK.jpg" alt="">
                  </div>
                  <span>Detik Health</span>
                </div>
                <span class="mai-time"></span> 1 day ago
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 py-2 wow zoomIn">
          <div class="card-blog">
            <div class="header">
              <div class="post-category">
                <a href="#">Health</a>
              </div>
              <a href='https://www.liputan6.com/health/read/4971889/kemenkes-temukan-sebagian-besar-data-kesehatan-tidak-update' class="post-thumb">
                <img src="../assets/img/blog/berita_3.jpg" alt="">
              </a>
            </div>
            <div class="body">
              <h5 class="post-title"><a href='https://www.liputan6.com/health/read/4971889/kemenkes-temukan-sebagian-besar-data-kesehatan-tidak-update'>Kemenkes Temukan Sebagian Besar Data Kesehatan Tidak Update</a></h5>
              <div class="site-info">
                <div class="avatar mr-2">
                  <div class="avatar-img">
                    <img src="../assets/img/person/LIPUTAN6.png" alt="">
                  </div>
                  <span>Liputan 6</span>
                </div>
                <span class="mai-time"></span> 8 day ago
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>