<div class="page-section pb-0">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 py-3 wow fadeInUp">
            <h1>Informasi Umum <br> tentang BPJS Kesehatan</h1>
            <p class="text-grey mb-4" style = "text-align:justify">BPJS Kesehatan (Badan Penyelenggara Jaminan Sosial Kesehatan) merupakan Badan Hukum Publik yang bertanggung jawab langsung kepada Presiden dan memiliki tugas untuk menyelenggarakan jaminan Kesehatan Nasional bagi seluruh rakyat Indonesia, terutama untuk Pegawai Negeri Sipil, Penerima Pensiun PNS dan TNI/POLRI, Veteran, Perintis Kemerdekaan beserta keluarganya dan Badan Usaha lainnya ataupun rakyat biasa. BPJS Kesehatan merupakan penyelenggara program jaminan sosial di bidang kesehatan yang merupakan salah satu dari lima program dalam Sistem Jaminan Sosial Nasional (SJSN), yaitu Jaminan Kesehatan, Jaminan Kecelakaan Kerja, Jaminan Hari Tua, Jaminan Pensiun, dan Jaminan Kematian sebagaimana tercantum dalam Undang-Undang Nomor 40 Tahun 2004 tentang Sistem Jaminan Sosial Nasional.</p>
            <a href="about.html" class="btn btn-primary">FAQ</a>
          </div>
          <div class="col-lg-6 wow fadeInRight" data-wow-delay="400ms">
            <div class="img-place custom-img-1">
              <img src="../assets/img/logo bpjs.png" alt="">
            </div>
          </div>
        </div>
      </div>
    </div<?php /**PATH C:\xampp\htdocs\OrhaInsurance\resources\views/user/aboutus.blade.php ENDPATH**/ ?>